library(testthat)
library(mockery)
test_check("SNVMutationTypes")
